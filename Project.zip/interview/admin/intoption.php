<!DOCTYPE html>
<html lang="en">

<head>
    <title>Document</title>
</head>

<body>
    <div class="panel-body">

        <p class="text-center">

            <a href="options.php" class="btn btn-primary btn-lg">Interviewer-1</a>
            <a href="options.php" class="btn btn-primary btn-lg">Interviewer-2</a>
            <a href="options.php" class="btn btn-primary btn-lg">Interviewer-3</a>

        </p>

    </div>
</body>

</html>