

<!DOCTYPE html>
<html lang="en">
<head>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
.i {
padding: 10px 5px;
border: 1px 1px;
font-size: 20px;
background-color: #b2d4e4;
border-radius: 8px;
color: red;
text-align: left;
}
</style>
<body>
<div class="container">
<?php include ('nav.php'); ?>
    <div id="signupbox" style=" margin-top:10px" class="mainbox col-md-12  col-sm-8 ">
        <div class="panel panel-info">
          
    </div>
</div>
</div>
    
<center>
    <a href="#"  class="i"> SELECT DEPARTMENT</a>
</center>
<br>
<center>
    <a href="ct2.php" style="width: 800px;" class="btn btn-primary">Computer Engineering</a>
</center><br>
<center>
    <a href="me2.php" style="width: 800px;" class="btn btn-primary">Mechanical Engineering</a>
</center><br>
<center>
    <a href="ce2.php" style="width: 800px;" class="btn btn-primary">Civil Engineering</a>
</center><br>
<center>
    <a href="el2.php" style="width: 800px;" class="btn btn-primary">Electronics Engineering</a>
</center><br>
<center>
    <a href="eee2.php" style="width: 800px;" class="btn btn-primary">Electrical And Electronics Engineering</a>
</center>

<br>
<center>
<a href="nav.php" style="width: 100px; margin-top: 5px;" class="btn btn-success">Back</a>
</center>
</body>
</html>




