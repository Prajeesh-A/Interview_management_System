  <nav class="navbar navbar-inverse" style="width: 81% !important; margin: auto;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="">Interview System</a>
    </div>
    <ul class="nav navbar-nav">
    <li><a href="image2.php">HOME PAGE</a></li>
      <li><a href="viewCandidate.php">View Candidates</a></li>
      <li><a href="ranking.php">RANKING</a></li>
      <li><a href="add.php">ADD ADMIN</a></li>
      <li><a href="viewscore.php">View Score </a></li>
      
     
    </ul>
  </div>
</nav>
