<!DOCTYPE html>
<html lang="en">
<head>
<title>Document</title>
</head>
<style>
.input {
padding: 20px 15px;
border: 1px 1px;
width: 40px;
height: 5px;
font-size: 20px;
background-color: #b2d4e4;
border-radius: 8px;
color: black;
text-align: left;
}
</style>
<body>
<center>
<table border="1">

 <tr>
    <th   style="width:90%">question</th>
    <th  style="width:9%">MARK</th>
 </tr>



 <tr>
    <td >what your age .......... </td>
    <td> 
<input type='text' name="input" id="input" class="input"></td>
 </tr>


 <tr>
    <td >next .......... </td>
    <td> 
<input type='text' name="input" id="input" class="input"></td>
 </tr>
 <tr>
    <td >what your age .......... </td>
    <td> 
<input type='text' name="input" id="input" class="input"></td>
 </tr>
 <tr>
    <td >what your age .......... </td>
    <td> 
<input type='text' name="input" id="input" class="input"></td>
 </tr>

<tr>
    <td>experience ........</td>
    <td>
<input type='text' name="input" id="input" class="input"></td>
 </tr>




</table>
</centre>
</body>
</html>