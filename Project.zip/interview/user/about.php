<!DOCTYPE html>
<html>
  <head>    
    <title>  Personal Website </title>
    <style>
     
    </style>
  </head>

      <body>
        <div class="container"> 
      
        <div class="header">
      <nav>
        <div class="logo">
          <h2> Personal Website </h2>
        </div>
        <ul>
            <div class="navigationlinks">
              
            <li><a href="viewCandidate.php">Home</a></li>

            <li><a href="about.php">About</a></li>

            

            <li><a href="contact.php">Contact</a></li>             
              </ul>
      </div>
          </nav>
          
      </div>
            <div class="maincontent">
                                             
       <h2>WELCOME! </h2>
       
       <img id="image1" src="https://i.imgur.com/X8lyaiY.png">
       <h1>The interview management system (IMS) is a web-based application that helps manage the process of recruiting candidates for various positions within a company. It includes features such as: </h1>
       <p>






1.Candidate registration: Candidates can register their details on the system.



2.Job posting: Employers can post job openings with details like job title, department, and requirements.



3.Candidate search: Recruiters can search for candidates based on their skills, experience, and other criteria.


4.Interview scheduling: Recruiters can schedule interviews for shortlisted candidates.


5.Conduct interview through personaly in representing colleges


5.Interview feedback: Interviewers can provide feedback on the performance of candidates.


6.Report generation: The system can generate reports on the status of job openings, interview schedules, and candidate performance </p>
       
       <center>
       <img src="https://images.vexels.com/media/users/3/153662/isolated/preview/e2c9370478afda97a2fa80b1fab515e6-facebook-colored-stroke-icon-by-vexels.png">
       <img src="https://www.freepnglogos.com/uploads/best-instagram-logo-download-here-15.png">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/Hangouts_icon.svg/207px-Hangouts_icon.svg.png">
         <img src="https://freepngimg.com/thumb/twitter/7-2-twitter-picture-thumb.png">
    </div>
              
              
            <div class="footer">
              <h1> Place your footer here </h>
    </div> 
  
     </body>
</html>
         
  
  
  







