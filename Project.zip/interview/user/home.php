  <nav class="navbar navbar-inverse" style="width: 81% !important; margin: auto;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="">Interview System</a>
    </div>
    <ul class="nav navbar-nav">
    <li><a href="image.php">HOME PAGE</a></li>
      
    </ul>
  </div>
</nav>
